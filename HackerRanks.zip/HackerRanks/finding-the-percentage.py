if __name__ == '__main__':
    n = int(input())
    student_marks = {}
    for _ in range(n):
        name, *line = input().split()
        scores = list(map(float, line))
        student_marks[name] = scores
    query_name = input()

    for i in student_marks:
        # print((student_marks[i]))
        # print((student_marks[i])[0])

        average=(((student_marks[i])[0])+((student_marks[i])[1])+((student_marks[i])[2]))/3

        if i == query_name:
            print(format(average, ".2f"))

    # print(student_marks)
