import textwrap


def wrap(string, max_width):
    myrange = int(len(string) / max_width)
    mylist = []
    for i in range(myrange):
        mylist.append(string[0:max_width])
        string = string[max_width:]

    return print(*mylist, sep='\n')


if __name__ == '__main__':
    string, max_width = input(), int(input())
    result = wrap(string, max_width)
    print(result)