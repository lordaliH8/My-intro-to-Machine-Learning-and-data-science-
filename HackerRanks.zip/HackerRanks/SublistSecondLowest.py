if __name__ == '__main__':
    python_class=[]
    scores=[]
    names=[]
    for _ in range(int(input())):
        name = input()
        score = float(input())
        scores.append(score)
        python_class.append([score,name])

    scores_set=sorted(list((set(scores))))
    second_lowest=scores_set[1]

    for i in range(len(python_class)):
        if python_class[i][0] == second_lowest:
            names.append(python_class[i][1])

    #print("\n".join(names))

    for i in sorted(names):
        print(i)


